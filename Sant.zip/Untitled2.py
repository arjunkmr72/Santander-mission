#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency
import seaborn as sns
from random import randrange, uniform


# In[2]:


os.chdir("C:/Users/Arun/Downloads")


# In[3]:


df = pd.read_csv("Santender.csv")


# In[4]:


df.shape


# In[5]:


df.describe()


# In[6]:


missing = pd.DataFrame(df.isnull().sum())


# In[7]:


missing


# In[8]:


get_ipython().run_line_magic('matplotlib', 'inline')
plt.boxplot(df['var_2'])


# In[9]:


cnames = ["var_0", "var_1", "var_2", "var_3", "var_4", "var_5", "var_6", "var_7", "var_8", "var_9", "var_10", "var_11", "var_12", "var_13", "var_14", "var_15", "var_16", "var_17", "var_18", "var_19", "var_20", "var_21", "var_22", "var_23", "var_24", "var_25", "var_26", "var_27", "var_28", "var_29", "var_30", "var_31", "var_32", "var_33", "var_34", "var_35", "var_36", "var_37", "var_38", "var_39", "var_40", "var_41", "var_42", "var_43", "var_44", "var_45", "var_46", "var_47", "var_48", "var_49", "var_50", "var_51", "var_52", "var_53", "var_54", "var_55", "var_56", "var_57", "var_58", "var_59", "var_60", "var_61", "var_62", "var_63", "var_64","var_65", "var_66", "var_67", "var_68", "var_69", "var_70", "var_71", "var_72", "var_73", "var_74", "var_75", "var_76", "var_77", "var_78", "var_79", "var_80", "var_81", "var_82", "var_83", "var_84", "var_85", "var_86", "var_87", "var_88", "var_90", "var_91", "var_92", "var_93", "var_94", "var_95", "var_96", "var_97", "var_98", "var_99", "var_100", "var_101", "var_102", "var_103", "var_104", "var_105", "var_106", "var_107", "var_108", "var_109", "var_110", "var_111", "var_112", "var_113", "var_114", "var_115", "var_116", "var_117", "var_118", "var_119", "var_120", "var_121", "var_122", "var_123", "var_124", "var_125", "var_126", "var_127", "var_128", "var_129", "var_130", "var_131", "var_132", "var_133", "var_134", "var_135", "var_136", "var_137", "var_138", "var_139", "var_140", "var_141", "var_142", "var_143", "var_144", "var_145", "var_146", "var_147", "var_148", "var_149", "var_150", "var_151", "var_152", "var_153", "var_154", "var_155", "var_156", "var_157", "var_158", "var_159", "var_160", "var_161", "var_162", "var_163", "var_164", "var_165", "var_166", "var_167", "var_168", "var_169", "var_170", "var_171", "var_172", "var_173", "var_174", "var_175", "var_176", "var_177", "var_178", "var_179", "var_180", "var_181", "var_182", "var_183", "var_184", "var_185", "var_186", "var_187", "var_188", "var_189", "var_190", "var_191", "var_192", "var_193", "var_194", "var_195", "var_196", "var_197","var_198", "var_199"
]


# In[10]:


for i in cnames:
    q75, q25 = np.percentile(df.loc[:, i], [75, 25])
    iqr = q75 - q25
    print(i)
    
    min = q25 - (iqr*1.5)
    max = q75 + (iqr*1.5)
    print(min)
    print(max)
    
    #df = df.drop(df[df.loc[:,i] < min].index)
    #df = df.drop(df[df.loc[:,i] > max].index)


# In[11]:


correlation = df.loc[:, cnames]
f, ax = plt.subplots(figsize= (7,5))
corr = correlation.corr()
sns.heatmap(corr, mask= np.zeros_like(corr,dtype=np.bool), cmap=sns.diverging_palette(220, 10, as_cmap=True), square=True, ax=ax)


# In[16]:


df = df.drop(['var_6'],axis=1)


# In[17]:


df.shape


# In[21]:


import statsmodels.api as sm
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor


# In[27]:


df1 = df.copy()
df2 = df.copy()
df3 = df.copy()
train, test = train_test_split(df1, test_size=0.2)
fit = DecisionTreeRegressor(max_depth=2).fit(train.iloc[:,0:9], train.iloc[:,9])
DT = fit.predict(test.iloc[:,0:9])
def MAPE(y_true, y_pred):
    mape = np.mean(np.abs((y_true - y_pred) / y_true))*100
    return mape
MAPE(test.iloc[:,9],DT)


# In[29]:


df2 = df.copy()
train, test = train_test_split(df2, test_size=0.2)
model = sm.OLS(train.iloc[:,9], train.iloc[:,0:9]).fit()
model.summary()
predictions_LR = model.predict(test.iloc[:,0:9]) 

def MAPE(y_true, y_pred): 
    mape = np.mean(np.abs((y_true - y_pred) / y_true))*100
    return mape

MAPE(test.iloc[:,9], predictions_LR)


# In[33]:


df3 = df.copy()
logit = sm.Logit(train['responded'], train[train_cols]).fit()
logit.summary()
test['Actual_prob'] = logit.predict(test[train_cols])
test['ActualVal'] = 1
test.loc[test.Actual_prob < 0.5, 'ActualVal'] = 0
CM = pd.crosstab(test['responded'], test['ActualVal'])
TN = CM.iloc[0,0]
FN = CM.iloc[1,0]
TP = CM.iloc[1,1]
FP = CM.iloc[0,1]
((TP+TN)*100)/(TP+TN+FP+FN)
(FN*100)/(FN+TP)


# In[ ]:




