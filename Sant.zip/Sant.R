rm(list=ls())
setwd("C:/Users/Arun/Downloads")
getwd()
x = c("ggplot2", "corrgram", "DMwR", "caret", "randomForest", "unbalanced", "C50", "dummies", "e1071", "Information",
+       "MASS", "rpart", "gbm", "ROSE", 'sampling', 'DataCombine', 'inTrees')
install.packages(x)
lapply(x, require, character.only = TRUE)
rm(x)
df = read.csv("Santender.csv", header = T)
missing = data.frame(apply(df,2,function(x){sum(is.na(x))}))
numeric_index = sapply(df,is.numeric) 
numeric_data = marketing_train[,numeric_index]
cnames = colnames(numeric_data)
for (i in 1:length(cnames))
{
assign(paste0("gn",i), ggplot(aes_string(y = (cnames[i]), x = "target"), data = subset(df))+ 
stat_boxplot(geom = "errorbar", width = 0.5) +
geom_boxplot(outlier.colour="red", fill = "grey" ,outlier.shape=1,
outlier.size=1, notch=FALSE) +
theme(legend.position="bottom")+
labs(y=cnames[i],x="target")+
ggtitle(paste("Box plot of target for",cnames[i])))
}
gridExtra::grid.arrange(gn1,gn5,gn2,ncol=3)
gridExtra::grid.arrange(gn6,gn7,ncol=2)
val = df$previous[df$previous %in% boxplot.stats(df$previous)$out]
df = df[which(!df$previous %in% val),]
for(i in cnames){
 print(i)
val = df[,i][df[,i] %in% boxplot.stats(df[,i])$out]
print(length(val))
df = df[which(!df[,i] %in% val),]}
corrgram(marketing_train[,numeric_index], order = F,
upper.panel=panel.pie, text.panel=panel.txt, main = "Correlation Plot")
logit_model = glm(responded ~ ., data = train, family = "binomial")
summary(logit_model)
logit_Predictions = predict(logit_model, newdata = test, type = "response")
logit_Predictions = ifelse(logit_Predictions > 0.5, 1, 0)
ConfMatrix_RF = table(test$target, logit_Predictions)
FNR = FN/FN+TP 
#Accuracy: 91
#FNR: 68
library(e1071)
NB_model = naiveBayes(target ~ ., data = train)
NB_Predictions = predict(NB_model, test[,1:16], type = 'class')
Conf_matrix = table(observed = test[,17], predicted = NB_Predictions)
confusionMatrix(Conf_matrix)
#Accuracy: 85
#FNR: 53
library(rpart)
library(MASS)
train_index = sample(1:nrow(df), 0.8 * nrow(df))
train = df[train_index,]
test = df[-train_index,]
fit = rpart(bwt ~ ., data = train, method = "anova")
predictions_DT = predict(fit, test[,-10])
MAPE = function(y, yhat){
  mean(abs((y - yhat)/y))
}	
MAPE(test[,10], predictions_DT)

#Error Rate: 10
#Accuracy: 89





