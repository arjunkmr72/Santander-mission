#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency
import seaborn as sns
from random import randrange, uniform


# In[2]:


os.chdir("C:/Users/Arun/Downloads")


# In[3]:


os.getcwd()


# In[4]:


df = pd.read_csv("day.csv")


# In[5]:


df.head


# In[6]:


df.shape


# In[7]:


missing = pd.DataFrame(df.isnull().sum())


# In[8]:


missing


# In[9]:


get_ipython().run_line_magic('matplotlib', 'inline')
plt.boxplot(df['instant'])


# In[10]:


plt.boxplot(df['mnth'])


# In[11]:


cnames = ["instant", "season" , "yr", "mnth", "holiday", "weekday", "workingday" , "weathersit", "temp", "atemp", "hum", "windspeed", "casual", "registered", "cnt"]


# In[12]:


cnames


# In[13]:


for i in cnames:
    q75, q25 = np.percentile(df.loc[:, i], [75, 25])
    iqr = q75 - q25
    print(i)
    
    min = q25 - (iqr*1.5)
    max = q75 + (iqr*1.5)
    print(min)
    print(max)
    
    df = df.drop(df[df.loc[:,i] < min].index)
    df = df.drop(df[df.loc[:,i] > max].index)


# In[14]:


df.shape


# In[15]:


correlation = df.loc[:, cnames]
f, ax = plt.subplots(figsize= (7,5))
corr = correlation.corr()
sns.heatmap(corr, mask= np.zeros_like(corr,dtype=np.bool), cmap=sns.diverging_palette(220, 10, as_cmap=True), square=True, ax=ax)


# In[38]:


df = df.drop(['holiday'], axis=1)


# In[37]:


df.shape


# In[20]:


get_ipython().run_line_magic('matplotlib', 'inline')
plt.hist(df['season'], bins='auto')


# In[21]:


cnames = ["instant", "season" , "yr", "mnth", "weekday", "workingday" , "weathersit", "temp", "atemp", "hum", "windspeed", "casual", "registered", "cnt"]


# In[22]:


cnames


# In[30]:


import statsmodels.api as sm
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor


# In[31]:


df


# In[32]:


train, test = train_test_split(df, test_size=0.2)


# In[34]:


fit = DecisionTreeRegressor(max_depth=2).fit(train.iloc[:,0:9], train.iloc[:,9])


# In[39]:


df = df.drop(['dteday'], axis=1)


# In[40]:


df.shape


# In[41]:


df


# In[42]:


train, test = train_test_split(df, test_size=0.2)


# In[43]:


fit = DecisionTreeRegressor(max_depth=2).fit(train.iloc[:,0:9], train.iloc[:,9])


# In[52]:


fit


# In[53]:


DT = fit.predict(test.iloc[:,0:9])


# In[54]:


DT


# In[55]:


def MAPE(y_true, y_pred):
    mape = np.mean(np.abs((y_true - y_pred) / y_true))*100
    return mape


# In[56]:


MAPE(test.iloc[:,9],DT)


# In[ ]:




