rm(list = ls())
setwd(C:/Users/Arun/Downloads)
getwd()
install.packages((c("dplyr","plyr","reshape","ggplot2","data.table"))
)
df = read.csv("day.csv", header = T)
View(df)
str(df)
colnames(df)
day$raw.temp =(day$temp*41)
head(day)
spring = subset(day, season == 1)$raw.temp
sp.mean = mean(spring) 
sp.median = median(spring) 
sp.sd = sd(spring) 
hist(x = spring, 
     main = "Temperatures in Spring", 
     xlab = "Temperature in Celcius", 
     ylab = "Number of Days",
     xlim = c(0, 25),
     ylim = c(0, 45))

abline(v = sp.mean, lwd = 2, lty = 1, col = "red")  
text(x = 17, y = 35, 
     labels = paste("Mean = ", round(mean(spring),2), sep = ""), col="red" )

abline(v = sp.median, lwd = 2, lty = 3, col = "blue") 
text(x = 6, y = 35, 
     labels = paste("Median = ", round(median(spring),2), sep = ""), col="blue" )
summer =subset(day, season == 2)$raw.temp
su.mean = mean(summer) 
su.median = median(summer) 
su.shist(x = summer, 
         main = "Temperatures in Summer", 
         xlab = "Temperature in Celcius", 
         ylab = "Number of Days", 
         xlim = c(0, 35), ylim = c(0, 40)
)
abline(v = su.mean, lwd = 2, lty = 1, col = "red") 
text( x = 15, y = 40, 
      labels = paste("Mean = ", round(mean(summer),2), sep = ""),
      col = "red")

abline(v = su.median, lwd = 2, lty = 3, col = "blue") 
text(x = 31, y = 40, 
     labels = paste("Median = ", round(median(summer),2), sep = ""), col = "blue" )d = sd(summer) 
fall = subset(day, season == 3)$raw.temp
fa.mean = mean(fall)
fa.median = median(fall)
fa.sd = sd(fall)
hist(x = fall, 
     main = "Temperatures in Fall", 
     xlab = "Temperature in Celcius", 
     ylab = "Number of Days", 
     xlim = c(15, 40), ylim = c(0, 70)
)
abline(v = fa.mean, lwd = 2, lty = 1, col = "red") 
text(x = 24, y = 60, 
     labels = paste("Mean = ", round(mean(fall),3), sep = ""), col = "red" )

abline(v = fa.median, lwd = 2, lty = 3, col ="blue") 
text(x = 35, y = 60, 
     labels = paste("Median = ", round(median(fall),3), sep = ""), col ="blue" )
winter = subset(day, season == 4)$raw.temp
wn.mean = mean(winter)
wn.median = median(winter)
wn.sd = sd(winter)
hist(x = winter, 
     main = "Temperatures in Winter", 
     xlab = "Temperature in Celcius", 
     ylab = "Number of Days", 
     xlim = c(0, 30), ylim = c(0, 40)
)

abline(v = wi.mean, lwd = 2, lty = 1, col = "red")  
text(x = 23, y = 40, 
     labels = paste("Mean = ", round(mean(winter),2), sep = ""), col = "red" )

abline(v = wi.median, lwd = 2, lty = 3, col ="blue") 
text(x = 10, y = 40, 
     labels = paste("Median = ", round(median(winter),2), sep = ""), col ="blue" )
x = c("ggplot2", "corrgram", "DMwR", "caret", "randomForest", "unbalanced", "C50", "dummies", "e1071", "Information",
      "MASS", "rpart", "gbm", "ROSE", 'sampling', 'DataCombine', 'inTrees')
lapply(x, require, character.only = TRUE)
rm(x)
numeric_index = sapply(df,is.numeric) #selecting only numeric

numeric_data = df[,numeric_index]

cnames = colnames(numeric_data)
for (i in 1:length(cnames))
   { 
  assign(paste0("gn",i), ggplot(aes_string(y = (cnames[i]), x = "responded"), data = subset(df))+ 
  stat_boxplot(geom = "errorbar", width = 0.5) +
  geom_boxplot(outlier.colour="red", fill = "grey" ,outlier.shape=18,
  outlier.size=1, notch=FALSE) +
  theme(legend.position="bottom")+
  labs(y=cnames[i],x="responded")+
  ggtitle(paste("Box plot of responded for",cnames[i])))
}
gridExtra::grid.arrange(gn6,gn7,ncol=2)
gridExtra::grid.arrange(gn2,gn5,ncol=2)
val = df$previous[df$previous %in% boxplot.stats(df$previous)$out]
df = df[which(!df$previous %in% val),]
for(i in cnames){
 print(i)
val = df[,i][df[,i] %in% boxplot.stats(df[,i])$out]
print(length(val))
df = df[which(!df[,i] %in% val),]
library(rpart)
library(MASS)
View(df)
train_index = sample(1:nrow(df), 0.8 * nrow(df))
train = df[train_index,]
test = df[-train_index,]
fit = rpart(bwt ~ ., data = train, method = "anova")
predictions_DT = predict(fit, test[,-10])
MAPE = function(y, yhat){
  mean(abs((y - yhat)/y))
}

MAPE(test[,10], predictions_DT)

library(usdm)
vif(df[,-10])

vifcor(df[,-10], th = 0.9)

lm_model = lm(bwt ~., data = train)
summary(lm_model)
predictions_LR = predict(lm_model, test[,1:9])
MAPE(test[,10], predictions_LR)

  
              
  